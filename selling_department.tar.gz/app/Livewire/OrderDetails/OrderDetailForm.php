<?php

namespace App\Livewire\OrderDetails;

use Livewire\Component;

class OrderDetailForm extends Component
{
    public function render()
    {
        return view('livewire.order-details.order-detail-form');
    }
}
