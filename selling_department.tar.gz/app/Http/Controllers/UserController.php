<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;

class UserController extends Controller
{

    public function index()
    {
       
       
        $this->authorize('viewAny', User::class);
        
     
            return view(
                'users.index',
                [
                    'users' => User::paginate(
                        config('pagination.default')
                    )
            
                ]
            );

    }


    public function create()
    {
        //$this->authorize('create', User::class);
        return view(
            'users.form'
        );
    }


    public function edit(User $user)
    {
        //$this->authorize('update', $user);

        return view(
            'users.form',
            [
                'user'=> $user,
            ]
        );
    }

    public function show(User $user, ?string $history =null)
    {
        //$this->authorize('update', $user);
        $orders=null;
        if($history=='true'){
            $orders= Order::query()
            ->where('orders.client_id', '=', $user->id)->get();

            $i=0;
            $products_array=array();
            foreach($orders as $o){
                $p1 = $o->products->pluck('id')->toArray();
                $products_array=array_push($p1);
                // $p2=Product::query()->where('products.id', '=', $p1[$i])->get();
                // $products_array= array_merge($p2);
            }
            
        }


        return view(
            'users.show',
            [
                'user'=> $user,
                'orders' => $orders,
                'products_array'=>$products_array,
            ]
        );
    }

}
