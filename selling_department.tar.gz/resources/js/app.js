import './bootstrap';

import './../../vendor/power-components/livewire-powergrid/dist/powergrid'
import './../../vendor/power-components/livewire-powergrid/dist/tailwind.css'
import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
import 'flowbite';
//import TomSelect from "tom-select";
//import "tom-select/dist/css/tom-select.min.css";
//window.TomSelect = TomSelect;