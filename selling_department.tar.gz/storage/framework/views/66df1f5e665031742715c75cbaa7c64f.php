<tr
    class="<?php echo e(theme_style($theme, 'table.header.tr')); ?>"
>
    <th
        class="<?php echo e(theme_style($theme, 'table.body.tdEmpty')); ?>"
        colspan="999"
    >
        <?php echo $this->processNoDataLabel; ?>

    </th>
</tr>
<?php /**PATH /var/www/html/resources/views/vendor/livewire-powergrid/components/table/th-empty.blade.php ENDPATH**/ ?>