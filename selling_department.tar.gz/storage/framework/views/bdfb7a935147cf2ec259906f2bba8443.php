<div>
    <?php if ($__env->exists(data_get($setUp, 'header.includeViewOnTop'))) echo $__env->make(data_get($setUp, 'header.includeViewOnTop'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mb-3 md:flex md:flex-row w-full justify-between items-center">
        <div class="md:flex md:flex-row w-full gap-1">
            <div x-data="pgRenderActions">
                <span class="pg-actions" x-html="toHtml"></span>
            </div>
            <div class="flex flex-row items-center text-sm flex-wrap">
                <!--[if BLOCK]><![endif]--><?php if(data_get($setUp, 'exportable')): ?>
                    <div
                        class="mr-2 mt-2 sm:mt-0"
                        id="pg-header-export"
                    >
                        <?php echo $__env->make(data_get($theme, 'root') . '.header.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if ($__env->exists(data_get($theme, 'root') . '.header.toggle-columns')) echo $__env->make(data_get($theme, 'root') . '.header.toggle-columns', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if ($__env->exists(data_get($theme, 'root') . '.header.soft-deletes')) echo $__env->make(data_get($theme, 'root') . '.header.soft-deletes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--[if BLOCK]><![endif]--><?php if(config('livewire-powergrid.filter') == 'outside' && count($this->filters()) > 0): ?>
                    <?php if ($__env->exists(data_get($theme, 'root') . '.header.filters')) echo $__env->make(data_get($theme, 'root') . '.header.filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php echo $__env->renderWhen(boolval(data_get($setUp, 'header.wireLoading')),
                data_get($theme, 'root') . '.header.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        </div>
        <?php echo $__env->make(data_get($theme, 'root') . '.header.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php if ($__env->exists(data_get($theme, 'root') . '.header.enabled-filters')) echo $__env->make(data_get($theme, 'root') . '.header.enabled-filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->renderWhen(data_get($setUp, 'exportable.batchExport.queues', 0), data_get($theme, 'root') . '.header.batch-exporting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    <?php echo $__env->renderWhen($multiSort, data_get($theme, 'root') . '.header.multi-sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    <?php if ($__env->exists(data_get($setUp, 'header.includeViewOnBottom'))) echo $__env->make(data_get($setUp, 'header.includeViewOnBottom'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if ($__env->exists(data_get($theme, 'root') . '.header.message-soft-deletes')) echo $__env->make(data_get($theme, 'root') . '.header.message-soft-deletes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /var/www/html/resources/views/vendor/livewire-powergrid/components/frameworks/tailwind/header.blade.php ENDPATH**/ ?>