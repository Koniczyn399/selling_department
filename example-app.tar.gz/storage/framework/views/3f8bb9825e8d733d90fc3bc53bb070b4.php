<span><?php echo $noDataLabel; ?></span>
<?php /**PATH /var/www/html/resources/views/vendor/livewire-powergrid/components/table/no-data-label.blade.php ENDPATH**/ ?>