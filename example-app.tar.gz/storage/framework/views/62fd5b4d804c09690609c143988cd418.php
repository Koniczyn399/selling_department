<div>
    <!--[if BLOCK]><![endif]--><?php if(flash()->hasMessages()): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = flash()->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                Wireui.hook('notifications:load', () => {
                    window.$wireui.notify({
                        title: '<?php echo e($message->title); ?>',
                        description: '<?php echo e($message->description); ?>',
                        icon: '<?php echo e($message->icon); ?>'
                    })
                });
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /var/www/html/resources/views/livewire/flash-notifications/flash-notifications.blade.php ENDPATH**/ ?>