<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white-800 leading-tight">
            <?php echo e(__('translation.navigation.orderdetails')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-2">
                <div class="grid justify-items-stretch py-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Order::class)): ?>
                        <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => ''.e(__('orders.actions.create')).'','href' => ''.e(route('orders.create')).'','class' => 'justify-self-end']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>




                <div class="py-12">

                    <?php $__currentLoopData = $single_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e(__('orders.attributes.order_id')); ?>: <?php echo e($that_order_id=$order->id); ?> <br>
                        <?php echo e(__('orders.attributes.client_name')); ?>: <?php echo e($order->worker_name); ?><br>
                        <?php echo e(__('orders.attributes.worker_name')); ?>: <?php echo e($order->client_name); ?><br>
                        <?php echo e(__('orders.attributes.order_state_name')); ?>: <?php echo e($order->order_state_name); ?><br>
                        <?php echo e(__('orders.attributes.price')); ?>: <?php echo e($order->price); ?><br>
                        <?php echo e(__('orders.attributes.deadline_of_completion')); ?>: <?php echo e($order->deadline_of_completion); ?><br>
                        <?php echo e(__('orders.attributes.date_of_completion')); ?>: <?php echo e($order->date_of_completion); ?><br>
                        <?php echo e(__('orders.attributes.description')); ?>: <?php echo e($order->description); ?><br>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-2">
                            <div class="container">
                                <div class="shadow-lg rounded-lg overflow-hidden mx-4">
                                    <table class="w-full table-fixed">
                                        <thead>
                                            <tr class="bg-gray-100">
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.order_product_id')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.order_id')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.product_name')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.amount')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.price')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.attributes.description')); ?>

                                                </th>
                                                <th class="w-1/4 py-4 px-6 text-left text-gray-600 font-bold uppercase">
                                                    <?php echo e(__('orderproducts.actions.actions')); ?>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white">
                                            <?php $__currentLoopData = $OrderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php echo e($OrderProduct->id); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200 truncate">
                                                        <?php echo e($OrderProduct->order_id); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php echo e($OrderProduct->product_name); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php echo e($OrderProduct->amount); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php echo e($OrderProduct->price); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php echo e($OrderProduct->description); ?>

                                                    </td>
                                                    <td class="py-4 px-6 border-b border-gray-200">
                                                        <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => ''.e(__('orderproducts.actions.edit_orderproduct_action')).'','href' => ''.e(route('orderproducts.edit', [$OrderProduct])).'','class' => 'justify-self-end']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                                                        
                                                        <form action="<?php echo e(route('orderproducts.anihilate')); ?>" method="get">
                                                            <?php echo e(csrf_field()); ?>

                                                            <div class="form-group">
                                                                <input type="text" hidden="hidden" name='order_product_id' value='<?php echo e($OrderProduct->id); ?>'/>
                                                                <input type="text" hidden="hidden" name='order_id' value='<?php echo e($that_order_id); ?>' />
                                                            </div>
                                                                <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','primary' => true,'label' => ''.e(__('orderproducts.actions.remove_orderproduct_action')).'','spinner' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                                                            </div>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="m-4">
                                    
                                </div>
                            </div>
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', App\Models\Order::class)): ?>
                            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wireui-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => ''.e(__('orders.actions.show_orders_action')).'','href' => ''.e(route('orders.index')).'','class' => 'justify-self-end']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/orders/show.blade.php ENDPATH**/ ?>