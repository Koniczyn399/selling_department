<input <?php echo e($attributes->merge(['type' => 'hidden'])); ?> />
<?php /**PATH /var/www/html/vendor/wireui/wireui/src/Components/Wrapper/views/components/hidden.blade.php ENDPATH**/ ?>