<?php

return[
    'default' => env('DEFAULT_PAGINATION',10),
];