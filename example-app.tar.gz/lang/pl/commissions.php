<?php

return [
    'attributes' => [
        'commission_id' => 'ID Zlecenia',
        'client_name' => 'Klient',
        'worker_name' => 'Pracownik',
        'device_id' => 'ID Urządzenia',
        'device_imei' => 'Kod IMEI',
        'device_sn' => 'Kod SN',
        'deadline_of_completion' => 'Termin realizacji',
        'date_of_completion' => 'Data realizacji',
        'service_name' => 'Nazwa usługi',
        'description' => 'Opis',

    ],
    'actions' => [
        'remove_commission_action' => 'Usuń zlecenie',
        'add_commission_action' => 'Dodaj zlecenie',
        'edit_commission_action' => 'Zmodyfikuj zlecenie',
        'create' => 'Dodaj zlecenie',
        'choose_client' => 'Wybierz klienta',
        'choose_worker' => 'Wybierz pracownika',
        'choose_service' => 'Wybierz usługę',

    ],
    'labels' => [
        'create_form_title' => 'Tworzenie nowgo zlecenia',
        'edit_form_title' => 'Edycja zlecenia',
    ],
    'messages' => [
        'successes' => [
            'stored' => 'Dodano zlecenie :name',
            'updated' => 'Zaktualizowano zlecenie :name',
            'destroyed' => 'Usunięto zlecenie :name',
            'restored' => 'Przywrócono zlecenie :name',
        ],
    ],

];
