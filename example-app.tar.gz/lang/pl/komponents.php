<?php

return [
    'attributes' => [
        'komponent_id' => 'ID',
        'komponent_name' => 'Nazwa komponentu',
        'price' => 'Cena',
        'description' => 'Opis',
    ],

    'labels' => [
        'create_form_title' => 'Tworzenie nowego komponentu',
        'edit_form_title' => 'Edycja komponentu',
    ],
    'actions' => [
        'remove_komponent_action' => 'Usuń komponent',
        'add_komponent_action' => 'Dodaj komponent',
        'edit_komponent_action' => 'Zmodyfikuj komponent',
        'create' => 'Dodaj komponent',

    ],

    'messages' => [
        'successes' => [
            'stored' => 'Dodano komponent :name',
            'updated' => 'Zaktualizowano komponent :name',
            'destroyed' => 'Usunięto komponent :name',
            'restored' => 'Przywrócono komponent :name',
        ],
    ],

];
