<?php

return [
    'attributes' => [
        'service_id' => 'ID',
        'category_name' => 'Nazwa kategorii',
        'service_name' => 'Nazwa usługi',
        'price' => 'Cena',
        'unit' => 'Jednostka',
        'description' => 'Opis',
    ],

    'labels' => [
        'create_form_title' => 'Tworzenie nowej usługi',
        'edit_form_title' => 'Edycja usługi',
    ],
    'actions' => [
        'remove_service_action' => 'Usuń usługę',
        'add_service_action' => 'Dodaj usługę',
        'edit_service_action' => 'Zmodyfikuj usługę',
        'create' => 'Dodaj usługę',
        'choose_category' => 'Wybierz kategorię',
        'choose_commission' => 'Wybierz zlecenie',
        'choose_order' => 'Wybierz zamówienie',


    ],
    'messages' => [
        'successes' => [
            'stored' => 'Dodano usługę :name',
            'updated' => 'Zaktualizowano usługę :name',
            'destroyed' => 'Usunięto usługę :name',
            'restored' => 'Przywrócono usługę :name',
        ],
    ],

];
