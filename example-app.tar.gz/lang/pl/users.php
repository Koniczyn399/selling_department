<?php

return[
    'attributes' =>[
        'id'=> 'ID',
        'name'=>'Imię i nazwisko',
        'email'=>'Email',
        'roles'=>'Role',
    ],
    'actions' => [
        'assign_admin_role' => 'Ustaw rolę admina',
        'remove_admin_role' => 'Odbierz rolę admina',
        'assign_worker_role' => 'Ustaw rolę pracownika',
        'remove_worker_role' => 'Odbierz rolę pracownika',
    ],
];