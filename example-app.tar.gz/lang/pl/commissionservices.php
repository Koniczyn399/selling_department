<?php

return [
    'attributes' => [
        'ID'=> 'ID',
        'commission_id'=> 'ID Zlecenia',
        'service_name'=> 'Nazwa usługi',
        'amount' => 'Ilość',
        'price'=> 'Cena',
        'description'=> 'Opis',

    ],
    'actions' => [
        'remove_commissionservice_action' => 'Usuń usługę zlecenia',
        'add_commissionservice_action' => 'Dodaj usługę zlecenia',
        'edit_commissionservice_action' => 'Zmodyfikuj usługę zlecenia',
        'create' => 'Dodaj usługę zlecenia',

    ],
    'labels' => [
        'create_form_title' => 'Tworzenie nowgo zlecenia',
        'edit_form_title' => 'Edycja zlecenia',
    ],
    'messages' => [
        'successes' => [
            'stored' => 'Dodano zlecenie :name',
            'updated' => 'Zaktualizowano zlecenie :name',
            'destroyed' => 'Usunięto zlecenie :name',
            'restored' => 'Przywrócono zlecenie :name',
        ],
    ],

];
