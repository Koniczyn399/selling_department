<?php

return [
    'attributes' => [
        'commission_komponent_id' => 'ID ',
        'commission_id' => 'ID Zlecenia',
        'commission' => 'Zlecenie',
        'product_name' => 'Nazwa produktu',
        'description' => 'Opis',
        'amount' => 'Ilość',
        'price' => 'Cena',
        'deadline_of_completion' => 'Termin realizacji',
        'date_of_completion' => 'Data realizacji',
        'service_id' => 'Kod usługi',
        'product_id' => 'Kod produktu',

    ],
    'actions' => [
        'remove_commissionkomponent_action' => 'Usuń zlecenie',
        'add_commissionkomponent_action' => 'Dodaj pozycję zlecenia',
        'edit_commissionkomponent_action' => 'Zmodyfikuj pozycję zlecenia',
        'create' => 'Dodaj pozycję zlecenia',
        'choose_product' => 'Wybierz produkt',
    ],
    'labels' => [
        'create_form_title' => 'Tworzenie nowej pozycji zlecenia',
        'edit_form_title' => 'Edycja pozycji zlecenia',
    ],
    'messages' => [
        'successes' => [
            'stored' => 'Dodano pozycję zlecenie :name',
            'updated' => 'Zaktualizowano pozycję zlecenia :name',
            'destroyed' => 'Usunięto pozycję zlecenie :name',
            'restored' => 'Przywrócono pozycję zlecenie :name',
        ],
    ],

];
