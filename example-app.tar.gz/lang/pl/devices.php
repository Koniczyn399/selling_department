<?php

return [
    'attributes' => [
        'device_id' => 'ID',
        'brand' => 'Marka',
        'model' => 'Model',
        'description' => 'Opis',
    ],
    'actions' => [
        'remove_device_action' => 'Usuń urządzenie',
        'add_device_action' => 'Dodaj urządzenie',
        'edit_device_action' => 'Zmodyfikuj urządzenie',
        'create' => 'Dodaj urządzenie',

    ],
    'labels' => [
        'create_form_title' => 'Tworzenie nowego urządzenia',
        'edit_form_title' => 'Edycja urządzenia',
    ],
    'messages' => [
        'successes' => [
            'stored' => 'Dodano urządzenie :name',
            'updated' => 'Zaktualizowano urządzenie :name',
            'destroyed' => 'Usunięto urządzenie :name',
            'restored' => 'Przywrócono urządzenie :name',
        ],
    ],

];
