<?php

namespace Database\Seeders;

use App\Models\Komponent;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class KomponentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Komponent::factory()->count(50)->create();
    }
}
