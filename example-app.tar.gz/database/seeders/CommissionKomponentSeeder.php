<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\CommissionKomponent;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class CommissionKomponentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        CommissionKomponent::factory()->count(33)->create();
    }
}
