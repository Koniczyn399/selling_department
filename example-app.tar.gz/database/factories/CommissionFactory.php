<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\Device;
use App\Models\Service;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Commission>
 */
class CommissionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'client_id' => User::select('id')->orderByRaw('RAND()')->first()->id,
            'worker_id' => User::select('id')->orderByRaw('RAND()')->first()->id,
            
            'device_imei' => $this->faker->numberBetween(5000,10000),
            'device_sn' => $this->faker->numberBetween( 5000,10000),

            'deadline_of_completion' => $this->faker->dateTimeBetween(
                '- 8 weeks',
                '- 4 week',
            ),

            'date_of_completion' => $this->faker->dateTimeBetween(
                '- 8 weeks',
                '- 4 week',
            ),

            'service_id' => Service::select('id')->orderByRaw('RAND()')->first()->id,
            
            'description' => $this->faker->unique()->word(),

            'created_at' => $this->faker->dateTimeBetween(
                '- 8 weeks',
                '- 4 week',
            ),
            'updated_at' => $this->faker->dateTimeBetween(
                '- 4 weeks',
                '- 1 week',
            ),
            'deleted_at' => rand(0, 10) === 0
                ? $this->faker->dateTimeBetween(
                    '- 1 week',
                    '+ 2 weeks',
                )
                : null,
        ];
    }
}
