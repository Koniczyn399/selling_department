<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\Order;
use App\Models\Device;
use App\Models\Product;
use App\Models\Commission;
use App\Models\OrderState;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\CommissionKomponent>
 */
class CommissionKomponentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'commission_id' => Commission::select('id')->orderByRaw('RAND()')->first()->id,
            'product_id' => Product::select('id')->orderByRaw('RAND()')->first()->id,

            'amount' => $this->faker->numberBetween(1,50),
            'price' => $this->faker->numberBetween(1,3000),

            'description' => $this->faker->word(),

            'created_at' => $this->faker->dateTimeBetween(
                '- 8 weeks',
                '- 4 week',
            ),
            'updated_at' => $this->faker->dateTimeBetween(
                '- 4 weeks',
                '- 1 week',
            ),
            'deleted_at' => rand(0, 10) === 0
                ? $this->faker->dateTimeBetween(
                    '- 1 week',
                    '+ 2 weeks',
                )
                : null,
        ];
    }
}
