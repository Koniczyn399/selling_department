<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('commission_services', function (Blueprint $table) {
            $table->id();


            $table->unsignedBigInteger('commission_id');
            $table->foreign('commission_id')
                ->references('id')
                ->on('commissions')
                ->onDelete('no action');

            $table->unsignedBigInteger('service_id');
            $table->foreign('service_id')
                ->references('id')
                ->on('services')
                ->onDelete('no action');
            
            $table->string('amount', 4);
            $table->string ('price',5);
            $table->string('description', 25);


            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('commission_services');
    }
};
