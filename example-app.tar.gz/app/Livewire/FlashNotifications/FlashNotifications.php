<?php

namespace App\Livewire\FlashNotifications;

use Livewire\Component;

class FlashNotifications extends Component
{
    public function render()
    {
        return view('livewire.flash-notifications.flash-notifications');
    }
}
