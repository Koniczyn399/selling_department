<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Service extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
                            "category_id",
                            "service_name",
                            "price",
                            "unit",
                            "description",
                        ];


    public function categories()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
    public function commissionservices()
    {
        return $this->hasMany(CommissionService::class);
    }

    public function commissions()
    {
        return $this->hasMany(Commission::class);
    }
}
