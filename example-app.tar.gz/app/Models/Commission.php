<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Commission extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
                            "client_id",
                            "worker_id",
                            "device_id",
                            "device_imei",
                            "device_sn",
                            "deadline_of_completion",
                            "date_of_completion",
                            "service_id",
                            "description",
                        ];

    public function users()
    {
        return $this->belongsTo(User::class);
    }

    public function devices()
    {
        return $this->belongsTo(Device::class);
    }

    public function services()
    {
        return $this->belongsTo(Service::class);
    }

    public function commissionservices()
    {
        return $this->hasMany(CommissionService::class);
    }
}
