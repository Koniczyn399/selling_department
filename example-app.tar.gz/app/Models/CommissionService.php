<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CommissionService extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
                            "commission_id",
                            "service_id",
                            "amount",
                            "price",
                            "description",
                        ];

    public function commissions()
    {
        return $this->belongsTo(Commission::class,'commission_id');
    }

    public function services()
    {
        return $this->belongsTo(Service::class,'service_id');
    }
}
