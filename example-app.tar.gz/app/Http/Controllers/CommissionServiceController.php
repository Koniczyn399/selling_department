<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\CommissionService;
use App\Http\Requests\StoreCommissionServiceRequest;
use App\Http\Requests\UpdateCommisionServiceRequest;
use App\Http\Requests\UpdateCommissionServiceRequest;
use App\Models\Commission;

class CommissionServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->authorize('viewAny', CommissionService::class);
        return view(
            'commissionservices.index',
            data: [
                'commissionservices' => CommissionService::paginate(
                    config('pagination.default')
                )
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->authorize('create', CommissionService::class);
        $this->authorize('viewAny', Commission::class);
        $this->authorize('viewAny', Service::class);

        $commissions= Commission::query()->join('users as clients', first: function ($users) {
            $users->on('commissions.client_id', '=', 'clients.id');
        })->select([
            'commissions.id',
            'clients.name as client_name',
        ])->get();

        $services= Service::query()->select([
            'services.id',
            'services.service_name',
        ])->get();

        return view(
            'commissionservices.form',
            [
                "commissions"=>$commissions,
                "services"=>$services,
            ]
        );
    }

    /**
     * Store a newly created resource in storage.
     
    *public function store(StoreCommissionServiceRequest $request)
    *{
     *   //
    *}
*/
    /**
     * Display the specified resource.
     */
    public function show(CommissionService $commisionService)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CommissionService $commissionservice)
    {
        $this->authorize('create', $commissionservice);
        $this->authorize('viewAny', Commission::class);
        $this->authorize('viewAny', Service::class);

        $commissions= Commission::query()->join('users as clients', first: function ($users) {
            $users->on('commissions.client_id', '=', 'clients.id');
        })->select([
            'commissions.id',
            'clients.name as client_name',
        ])->get();

        $services= Service::query()->select([
            'services.id',
            'services.service_name',
        ])->get();

        return view(
            'commissionservices.form',
            [
                'commissionservice' => $commissionservice,
                "commissions"=>$commissions,
                "services"=>$services,
            ]
        );
    }
    

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCommissionServiceRequest $request, CommissionService $commisionService)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CommissionService $commisionService)
    {
        $this->authorize('delete', $commisionService);
    }
}
