<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreComponentRequest;
use App\Http\Requests\UpdateComponentRequest;
use App\Models\Komponent;

class KomponentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->authorize('viewAny', Komponent::class);
        return view(
            'komponents.index',
            data: [
                'komponents' => Komponent::paginate(
                    config('pagination.default')
                )
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->authorize('create', Komponent::class);
        

        return view(
            'komponents.form'
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreComponentRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Komponent $component)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Komponent $komponent)
    {
        $this->authorize('update', $komponent);
        //dd($component);
        return view(
            'komponents.form',
            [
                'komponent'=> $komponent,
            ]
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateComponentRequest $request, Komponent $component)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Komponent $komponent)
    {
        $this->authorize('delete', $komponent);
    }
}
