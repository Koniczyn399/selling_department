<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Service;
use App\Models\Category;
use App\Models\Commission;
use App\Http\Requests\StoreCommissionRequest;
use App\Http\Requests\UpdateCommissionRequest;

class CommissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->authorize('viewAny', Commission::class);

        return view(
            'commissions.index',
            data: [
                'commissions' => Commission::paginate(
                    config('pagination.default')
                )
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->authorize('create', Commission::class);
        $this->authorize('viewAny', User::class);
        $this->authorize('viewAny', Service::class);

        $users= User::query()->select([
            'users.id',
            'users.name',
        ])->get();

        $services= Service::query()->select([
            'services.id',
            'services.service_name',
        ])->get();


        

        return view(
            'commissions.form',
            [
                'users'=>$users,
                'services'=>$services,
            ]
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCommissionRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Commission $commision)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Commission $commission)
    {
        $this->authorize('update', $commission);
        $this->authorize('viewAny', User::class);
        $this->authorize('viewAny', Service::class);

        $users= User::query()->select([
            'users.id',
            'users.name',
        ])->get();

        $services= Service::query()->select([
            'services.id',
            'services.service_name',
        ])->get();

        //dd($commission);

        return view(
            'commissions.form',
            [
                'commission' => $commission,
                'users' => $users,
                'services' => $services,
            ]
        );
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCommissionRequest $request, Commission $commission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Commission $commission)
    {
        $this->authorize('delete', $commission);
    }
}
