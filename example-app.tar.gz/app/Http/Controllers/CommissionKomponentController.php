<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\CommisionKomponent;
use App\Models\CommissionKomponent;
use App\Http\Requests\StoreCommisionKomponentRequest;
use App\Http\Requests\UpdateCommisionKomponentRequest;
use App\Http\Requests\UpdateCommissionKomponentRequest;
use App\Models\Commission;
use App\Models\Order;

class CommissionKomponentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->authorize('viewAny', CommissionKomponent::class);
        return view(
            'commissionkomponents.index',
            data: [
                'commissionkomponents' => CommissionKomponent::paginate(
                    config('pagination.default')
                )
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->authorize('create', CommissionKomponent::class);

        $this->authorize('viewAny', Commission::class);
        $this->authorize('viewAny', Product::class);


        $commissions= Commission::query()->join('users as clients', function ($users) {
            $users->on('commissions.client_id', '=', 'clients.id');
        })->select([
            'commissions.id',
            'clients.name as client_name',
        ])->get();

        $products= Product::query()->select([
            'products.id',
            'products.product_name',
        ])->get();

        return view(
            'commissionkomponents.form',
            [
                "commissions"=>$commissions,
                "products"=>$products,
            ]
        );
    }

    /**
     * Store a newly created resource in storage.
    
    *public function store(StoreCommisionKomponentRequest $request)
    *{
    *    //
    *}
         */

    /**
     * Display the specified resource.
     */
    public function show(CommissionKomponent $commisionKomponent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CommissionKomponent $commissionkomponent)
    {
        //dd($commissionkomponent);
        $this->authorize('update', $commissionkomponent);

        $this->authorize('viewAny', Commission::class);
        $this->authorize('viewAny', Product::class);
        
        $commissions= Commission::query()->join('users as clients', first: function ($users) {
            $users->on('commissions.client_id', '=', 'clients.id');
        })->select([
            'commissions.id',
            'clients.name as client_name',
        ])->get();

        $products= Product::query()->select([
            'products.id',
            'products.product_name',
        ])->get();


        return view(
            'commissionkomponents.form',
            [
                'commissionkomponent'=> $commissionkomponent,
                "commissions"=>$commissions,
                "products"=>$products,
            ]
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCommissionKomponentRequest $request, CommissionKomponent $commisionKomponent)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CommissionKomponent $commisionKomponent)
    {
        $this->authorize('delete', $commisionKomponent);
    }
}
