<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Builder;
use App\Http\Requests\StoreServiceRequest;
use App\Http\Requests\UpdateServiceRequest;
use Illuminate\Database\Eloquent\Collection;

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $this->authorize('viewAny', arguments: Service::class);
        return view(
            'services.index',
            data: [
                'services' => Service::paginate(
                    config('pagination.default')
                )
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $this->authorize('create', Service::class);
        $this->authorize('viewAny', Category::class);
        
        $categories= Category::query()->select([
            'categories.id',
            'categories.category_name',
        ]);
        $categories= Category::orderBy('id','desc')->get();
        
        

        return view(
            'services.form',['categories'=>$categories]);
            //compact('categories')
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreServiceRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Service $service)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Service $service)
    {
        $this->authorize('create', $service);
        $this->authorize('viewAny', Category::class);

        $categories= Category::query()->select([
            'categories.id',
            'categories.category_name',
        ]);
        
        $categories= Category::orderBy('id','desc')->get();
        
        return view(
            'services.form',
            [
                'service'=> $service,
                'categories'=>$categories
            ]
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateServiceRequest $request, Service $service)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Service $service)
    {
        $this->authorize('delete', $service);
    }
}
